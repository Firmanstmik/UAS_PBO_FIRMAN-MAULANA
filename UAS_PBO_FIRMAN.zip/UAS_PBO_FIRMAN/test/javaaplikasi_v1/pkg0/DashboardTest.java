/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package javaaplikasi_v1.pkg0;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author FIR IT
 */
public class DashboardTest {
    
    public DashboardTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of panel_tabel_dokter method, of class Dashboard.
     */
    @Test
    public void testPanel_tabel_dokter() {
        System.out.println("panel_tabel_dokter");
        Dashboard instance = new Dashboard();
        instance.panel_tabel_dokter();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of panel_tabel_pasien method, of class Dashboard.
     */
    @Test
    public void testPanel_tabel_pasien() {
        System.out.println("panel_tabel_pasien");
        Dashboard instance = new Dashboard();
        instance.panel_tabel_pasien();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of reset_dokter method, of class Dashboard.
     */
    @Test
    public void testReset_dokter() {
        System.out.println("reset_dokter");
        Dashboard instance = new Dashboard();
        instance.reset_dokter();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of reset_pasien method, of class Dashboard.
     */
    @Test
    public void testReset_pasien() {
        System.out.println("reset_pasien");
        Dashboard instance = new Dashboard();
        instance.reset_pasien();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tampilkan_data_tabel_jadwal method, of class Dashboard.
     */
    @Test
    public void testTampilkan_data_tabel_jadwal() {
        System.out.println("tampilkan_data_tabel_jadwal");
        Dashboard instance = new Dashboard();
        instance.tampilkan_data_tabel_jadwal();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tampilkan_data_tabel_dokter method, of class Dashboard.
     */
    @Test
    public void testTampilkan_data_tabel_dokter() {
        System.out.println("tampilkan_data_tabel_dokter");
        Dashboard instance = new Dashboard();
        instance.tampilkan_data_tabel_dokter();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of tampilkan_data_tabel_pasien method, of class Dashboard.
     */
    @Test
    public void testTampilkan_data_tabel_pasien() {
        System.out.println("tampilkan_data_tabel_pasien");
        Dashboard instance = new Dashboard();
        instance.tampilkan_data_tabel_pasien();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Dashboard.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Dashboard.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
